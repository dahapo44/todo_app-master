import 'package:flutter/material.dart';
const TextStyle kNormalTextFormat=TextStyle(fontSize: 16,fontWeight: FontWeight.normal);
const String baseUrl="https://testapi.habraac.tech";